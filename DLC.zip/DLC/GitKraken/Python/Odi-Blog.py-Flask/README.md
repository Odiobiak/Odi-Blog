# Odi-Blog
Personal-Project: Developing a website! New to python and flask, so this is a way for me to learning and creating something useful at the same time!

this is a trying project for me. 
