﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DLCAdmin.SelfService.Contracts.Models
{
    public class SelfServiceSettingsResponse
    {
        public bool IsLoginOff {get; set;}
    }
}
