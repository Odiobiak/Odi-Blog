﻿using DLCAdmin.SelfService.Service.Injection;
using DLCAdmin.SelfService.Service.Workflows;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;

[assembly: WebJobsStartup(typeof(Startup))]
namespace DLCAdmin.SelfService.Service.Injection
{
    class Startup : IWebJobsStartup
    {
        readonly string ccsbUrl = Environment.GetEnvironmentVariable("CcsbUrl");

        public void Configure(IWebJobsBuilder builder)
        {
            //Don't need to create a new service collection just use the built-in one
            builder.Services.AddSingleton<ISelfServiceWorkflow, SelfServiceWorkflow>();

            //Registering an extension
            builder.AddExtension<InjectionConfiguration>();
        }
    }
}