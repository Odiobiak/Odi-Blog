﻿using DLCAdmin.SelfService.Service.Attributes;
using Microsoft.Azure.WebJobs.Host.Config;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace DLCAdmin.SelfService.Service.Injection
{
    public class InjectionConfiguration : IExtensionConfigProvider
    {
        readonly IServiceProvider _serviceProvider;

        public InjectionConfiguration(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ExtensionConfigContext context)
        {
            context.AddBindingRule<InjectAttribute>()
                .BindToInput<dynamic>(x => _serviceProvider.GetRequiredService(x.Type));
        }
    }
}