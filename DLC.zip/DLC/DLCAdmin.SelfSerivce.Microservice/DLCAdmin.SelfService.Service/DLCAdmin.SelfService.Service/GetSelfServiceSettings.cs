using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using DLCAdmin.SelfService.Service.Workflows;
using DLCAdmin.SelfService.Service.Attributes;

namespace DLCAdmin.SelfService.Service
{
    public static class Function1
    {
        [FunctionName("GetSelfServiceSettings")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetSelfServiceSettings")] HttpRequest req,
            [Inject(typeof(ISelfServiceWorkflow))]ISelfServiceWorkflow selfServiceWorkflow)
        {            
            var response = await selfServiceWorkflow.GetSettings();

            return (ActionResult)new OkObjectResult(response);
        }
    }
}