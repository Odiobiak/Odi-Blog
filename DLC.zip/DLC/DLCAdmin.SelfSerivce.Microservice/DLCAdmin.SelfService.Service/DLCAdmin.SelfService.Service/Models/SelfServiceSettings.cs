﻿using Microsoft.WindowsAzure.Storage.Table;

namespace DLCAdmin.SelfService.Service.Models
{
    public class SelfServiceSettings: TableEntity
    {
        public SelfServiceSettings()
        {
            PartitionKey = "selfServiceSettings";
            RowKey = "selfServiceSettings";
        }

        public bool? IsLoginOff { get; set; }
    }
}
