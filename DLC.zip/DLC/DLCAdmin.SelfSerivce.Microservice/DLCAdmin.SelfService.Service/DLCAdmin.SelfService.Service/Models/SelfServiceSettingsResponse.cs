﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DLCAdmin.SelfService.Service.Models
{
    public class SelfServiceSettingsResponse
    {
        public bool IsLoginOff { get; set; }
    }
}
