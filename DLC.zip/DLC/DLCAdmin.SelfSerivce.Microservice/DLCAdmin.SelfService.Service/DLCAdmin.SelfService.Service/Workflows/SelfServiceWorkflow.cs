﻿using System.Threading.Tasks;
using DLCAdmin.SelfService.Service.Models;
using Microsoft.WindowsAzure.Storage.Table;

namespace DLCAdmin.SelfService.Service.Workflows
{
    public class SelfServiceWorkflow : CloudTableBase, ISelfServiceWorkflow
    {
        public SelfServiceWorkflow() : base("azureTableName") { }

        public async Task<SelfServiceSettingsResponse> GetSettings()
        {
            var operation = TableOperation
                .Retrieve<SelfServiceSettings>("selfServiceSettings", "selfServiceSettings");

            var query = await Table.ExecuteAsync(operation);
            var settings = (SelfServiceSettings)query.Result;

            return new SelfServiceSettingsResponse
            {
                IsLoginOff = settings?.IsLoginOff.GetValueOrDefault() ?? false
            };
        }
    }
}