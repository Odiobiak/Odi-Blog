﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;

namespace DLCAdmin.SelfService.Service.Workflows
{
    public class CloudTableBase
    {
        public CloudTableBase(string tableKeyName)
        {
            var storageAccount = CloudStorageAccount
                .Parse(Environment.GetEnvironmentVariable("storageConnectionString"));

            var tableName = Environment.GetEnvironmentVariable(tableKeyName);

            var tableClient = storageAccount.CreateCloudTableClient();

            Table = tableClient.GetTableReference(tableName);

            Table.CreateIfNotExistsAsync();
        }

        protected CloudTable Table { get; set; }
    }
}