﻿using DLCAdmin.SelfService.Service.Models;
using System.Threading.Tasks;

namespace DLCAdmin.SelfService.Service.Workflows
{
    public interface ISelfServiceWorkflow
    {
        Task<SelfServiceSettingsResponse> GetSettings();
    }
}